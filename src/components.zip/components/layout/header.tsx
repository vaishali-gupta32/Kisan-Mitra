import { useState } from 'react'
import Link from "next/link"
import { Sun, Moon, Languages, Type } from 'lucide-react'
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Header() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light')
  const [fontSize, setFontSize] = useState(16)

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light'
    setTheme(newTheme)
    document.documentElement.classList.toggle('dark')
  }

  const changeFontSize = (delta: number) => {
    setFontSize(prevSize => {
      const newSize = prevSize + delta
      document.documentElement.style.fontSize = `${newSize}px`
      return newSize
    })
  }

  return (
    <header className="fixed top-0 w-full z-50 bg-transparent">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <span className="text-2xl font-bold text-white">KisanMitra</span>
        </Link>

        <nav className="flex items-center space-x-6">
          <Link href="/" className="text-sm font-medium text-white hover:text-primary">
            Home
          </Link>
          <Link href="/login" className="text-sm font-medium text-white hover:text-primary">
            Login
          </Link>
          <Link href="/help" className="text-sm font-medium text-white hover:text-primary">
            Help
          </Link>
          <Link href="/contact" className="text-sm font-medium text-white hover:text-primary">
            Contact Us
          </Link>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white">
                <Languages className="h-5 w-5" />
                <span className="sr-only">Change language</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>English</DropdownMenuItem>
              <DropdownMenuItem>हिन्दी</DropdownMenuItem>
              <DropdownMenuItem>मराठी</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" size="icon" onClick={toggleTheme} className="text-white">
            {theme === 'light' ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" onClick={() => changeFontSize(-1)} className="text-white">
              <Type className="h-4 w-4" />
              <span className="sr-only">Decrease font size</span>
            </Button>
            <Button variant="ghost" size="icon" onClick={() => changeFontSize(1)} className="text-white">
              <Type className="h-5 w-5" />
              <span className="sr-only">Increase font size</span>
            </Button>
          </div>
        </nav>
      </div>
    </header>
  )
}

