import React, { ReactNode } from 'react';

// Table component
export function Table({ children }: { children: ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full table-auto">{children}</table>
    </div>
  );
}

// TableHeader component
export function TableHeader({ children }: { children: ReactNode }) {
  return <thead className="bg-gray-100">{children}</thead>;
}

// TableRow component
export function TableRow({ children }: { children: ReactNode }) {
  return <tr className="border-b hover:bg-gray-50">{children}</tr>;
}

// TableCell component
export function TableCell({ children }: { children: ReactNode }) {
  return <td className="px-4 py-2 text-sm">{children}</td>;
}

// TableHead component
export function TableHead({ children }: { children: ReactNode }) {
  return (
    <th className="px-4 py-2 text-left text-sm font-semibold text-gray-600">
      {children}
    </th>
  );
}

// TableBody component
export function TableBody({ children }: { children: ReactNode }) {
  return <tbody>{children}</tbody>;
}
